#include <stdio.h> 
#include "tests.h" 
#include "fonctions.h"

int main(int argc,char *argv[]) 
{
#ifdef TEST
	test();
#else
	printf("%c\n",add('A',10)); 
#endif
}
