int compter_caractere(char *s, char c); 
char *sous_chaine(char *s, char c); 
int supprimer_espace(char *s);
int majuscule(char *s);
char *modifier_chiffre(char *s);
