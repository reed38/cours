#include <stdio.h> 
#include "fonctions.h" 

void test()
{
}

