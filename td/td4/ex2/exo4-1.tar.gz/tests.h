void test(); 

